package test.java.vac;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import main.java.grid.Direction;
import main.java.grid.GridObject;
import main.java.grid.GridPoint;
import main.java.grid.Square;

import org.junit.Test;


public class VacWorldParserTests {

	private static final String nl = System.getProperty("line.separator");
	
	@Test public void createSmallValidVacWorldTest() throws IOException, InvalidVacWorldException {
		String world = "nsew" + nl
				     + "NSEW" + nl
				     + " .X ";
		VacWorld vacWorld = new VacWorld(new ByteArrayInputStream(world.getBytes()));
		assertEquals(4, vacWorld.grid.sizeX);
		assertEquals(3, vacWorld.grid.sizeY);
		Square s;
		
		// First row
		s = vacWorld.grid.getSquareAt(new GridPoint(0,0));
		assertEquals(1, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.north));
		s = vacWorld.grid.getSquareAt(new GridPoint(1,0));
		assertEquals(1, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.south));
		s = vacWorld.grid.getSquareAt(new GridPoint(2,0));
		assertEquals(1, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.east));
		s = vacWorld.grid.getSquareAt(new GridPoint(3,0));
		assertEquals(1, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.west));
		
		// Second row
		s = vacWorld.grid.getSquareAt(new GridPoint(0,1));
		assertEquals(2, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(s.has(Dust.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.north));
		s = vacWorld.grid.getSquareAt(new GridPoint(1,1));
		assertEquals(2, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(s.has(Dust.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.south));
		s = vacWorld.grid.getSquareAt(new GridPoint(2,1));
		assertEquals(2, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(s.has(Dust.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.east));
		s = vacWorld.grid.getSquareAt(new GridPoint(3,1));
		assertEquals(2, s.getCount());
		assertTrue(s.has(VacBot.class));
		assertTrue(s.has(Dust.class));
		assertTrue(((VacBot)s.get(VacBot.class)).getDirection().equalsDirection(Direction.west));
		
		// Third row
		s = vacWorld.grid.getSquareAt(new GridPoint(0,2));
		assertEquals(0, s.getCount());
		s = vacWorld.grid.getSquareAt(new GridPoint(1,2));
		assertEquals(1, s.getCount());
		assertTrue(s.has(Dust.class));
		s = vacWorld.grid.getSquareAt(new GridPoint(2,2));
		assertEquals(1, s.getCount());
		assertTrue(s.has(GridObject.class));
		s = vacWorld.grid.getSquareAt(new GridPoint(3,2));
		assertEquals(0, s.getCount());
	}
	
	@Test (expected=InvalidVacWorldException.class)
	public void createTooNarrowVacWorldTest() throws IOException, InvalidVacWorldException {
		String world = "n" + nl
	                 + " " + nl
	                 + " ";
		new VacWorld(new ByteArrayInputStream(world.getBytes()));
	}
	
	@Test (expected=InvalidVacWorldException.class)
	public void createTooShortVacWorldTest() throws IOException, InvalidVacWorldException {
		String world = "n  ";
		new VacWorld(new ByteArrayInputStream(world.getBytes()));
	}
	
	@Test (expected=InvalidVacWorldException.class)
	public void createNonRectangularVacWorldTest() throws IOException, InvalidVacWorldException {
		String world = "n  " + nl
	                 + "    " + nl
	                 + "   ";
		new VacWorld(new ByteArrayInputStream(world.getBytes()));
	}
	
	@Test (expected=InvalidVacWorldException.class)
	public void createTooManyVacBotsTest() throws IOException, InvalidVacWorldException {
		String world = "nsew" + nl
	                 + "NSEW" + nl
	                 + "   n";
		new VacWorld(new ByteArrayInputStream(world.getBytes()));
	}
	
	@Test (expected=InvalidVacWorldException.class)
	public void createTooFewVacBotsTest() throws IOException, InvalidVacWorldException {
		String world = "  ." + nl
	                 + " X " + nl
	                 + "   ";
		new VacWorld(new ByteArrayInputStream(world.getBytes()));
	}
	
	@Test (expected=InvalidVacWorldException.class)
	public void illegalInputCharacterTest() throws IOException, InvalidVacWorldException {
		String world = "nsew" + nl
	                 + " .X " + nl
	                 + "q  X";
		new VacWorld(new ByteArrayInputStream(world.getBytes()));
	}
	
	@Test public void ignoreEmptyLinesTest() throws IOException, InvalidVacWorldException {
		// Empty lines before, after, and during should be ignored; space-only lines should be parsed as empty squares
		String world = "" + nl
			         + "nsew" + nl
	                 + "    " + nl
	                 + nl
	                 + " .X " + nl
	                 + nl;
		VacWorld vacWorld = new VacWorld(new ByteArrayInputStream(world.getBytes()));
		assertEquals(4, vacWorld.grid.sizeX);
		assertEquals(3, vacWorld.grid.sizeY);
	}
	
	@Test public void ignoreCommentLinesTest() throws IOException, InvalidVacWorldException {
		// Comment lines before, after, and during should be ignored
		String world = "#Comment 1. Blah." + nl
			         + "nsew" + nl
	                 + "    " + nl
	                 + "# Comment 2" + nl
	                 + " .X " + nl
	                 + "#### Comment 3.";
		VacWorld vacWorld = new VacWorld(new ByteArrayInputStream(world.getBytes()));
		assertEquals(4, vacWorld.grid.sizeX);
		assertEquals(3, vacWorld.grid.sizeY);
	}
}
