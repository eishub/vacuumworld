package test.java.vac;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import main.java.grid.GridObject;
import main.java.grid.Square;

import org.junit.Test;

public class VacWorldGeneratorTests {

	@Test public void addRandomDustTest() {
		VacWorld vw = new VacWorld(8,8);
		vw.addRandomDust(32);
		GridObject[] objects = getObjects(vw);
		assertEquals(32, objects.length);
		for (GridObject go : objects) {
			assertTrue(go.getClass().equals(Dust.class));
		}
	}
	
	@Test public void addRandomObstructionsTest() {
		VacWorld vw = new VacWorld(8,8);
		vw.addRandomObstructions(32);
		GridObject[] objects = getObjects(vw);
		assertEquals(32, objects.length);
		for (GridObject go : objects) {
			assertTrue(go.getClass().equals(GridObject.class));
		}
	}
	
	@Test public void addRandomVacBotsTest() {
		VacWorld vw = new VacWorld(8,8);
		vw.addRandomVacBots(8);
		GridObject[] objects = getObjects(vw);
		assertEquals(8, objects.length);
		for (GridObject go : objects) {
			assertTrue(go.getClass().equals(VacBot.class));
		}
		assertEquals(8, vw.getVacBots().length);
	}
	
	@Test public void generateLargeWorldTest() {
		VacWorld vw = new VacWorld(8);
		assertEquals(8, vw.getVacBots().length);
		GridObject[] objects = getObjects(vw);
		int vacs = 0;
		int dust = 0;
		int obstructions = 0;
		for (GridObject go : objects) {
			if (go.getClass().equals(VacBot.class)) vacs++;
			else if (go.getClass().equals(Dust.class)) dust++;
			else if (go.getClass().equals(GridObject.class)) obstructions++;
			else fail("Unexpected object of type \"" + go.getClass().getName() + "\" in grid!");
		}
		assertEquals(8, vacs);
		assertEquals(16, obstructions);
		assertEquals(64, dust);
	}
	
	private GridObject[] getObjects(VacWorld world) {
		List<GridObject> objects = new ArrayList<GridObject>();
		Iterator<Square> iterator = world.grid.scanIterator();
		while (iterator.hasNext()) {
			Square square = iterator.next();
			Iterator<GridObject> squareIterator = square.iterator();
			while (squareIterator.hasNext()) {
				objects.add(squareIterator.next());
			}
		}
		return objects.toArray(new GridObject[0]);
	}
}
