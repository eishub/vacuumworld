package test.java.vac;

import static org.junit.Assert.assertEquals;

import java.awt.Color;

import main.java.actions.ImpossibleActionException;
import main.java.actions.UnavailableActionException;
import main.java.grid.Direction;
import main.java.grid.Grid;
import main.java.grid.GridObject;
import main.java.grid.GridPoint;

import org.junit.Before;
import org.junit.Test;

public class VacBotTests {
	
	// 3 x 3 grid with TestVacBot in south middle square
	// Non-moving VacBot in the south west square and an obstacle in the south east
	// Dust in the middle square
	private final Grid testGrid = new Grid(3, 3);
	
	@Before public void setup() {
		new VacBot(testGrid, new GridPoint(0,2), Direction.north, "Bozo", Color.GRAY);
		new GridObject(testGrid, new GridPoint(2,2));
		new Dust(testGrid, new GridPoint(1,1));
	}

	@Test (expected=ImpossibleActionException.class)
	public void obstructedOneSquareMoveTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final VacBot vacBot = new TestVacBot(Direction.east);
		try {
		vacBot.move(1, Direction.east);
		} finally {
			assertEquals(1.0, vacBot.getX(), 0.001);
			assertEquals(2.0, vacBot.getY(), 0.001);
		}
	}
	
	@Test (expected=UnavailableActionException.class)
	public void occupiedOneSquareMoveTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final VacBot vacBot = new TestVacBot(Direction.west);
		try {
			vacBot.move(1, Direction.west);
		} finally {
			assertEquals(1.0, vacBot.getX(), 0.001);
			assertEquals(2.0, vacBot.getY(), 0.001);
		}
	}
	
	@Test public void moveOverDustTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final VacBot vacBot = new TestVacBot(Direction.north);
		vacBot.move(1, Direction.north);
		assertEquals(1.0, vacBot.getX(), 0.001);
		assertEquals(1.0, vacBot.getY(), 0.001);
	}
	
	private class TestVacBot extends VacBot {
		public TestVacBot(Direction direction) {
			super(testGrid, new GridPoint(1, 2), direction, "Barry", Color.ORANGE);
		}
	}
}
