package test.java.ei;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedList;

import main.java.grid.Direction;
import main.java.grid.RelativeDirection;
import main.java.util.ei.PerceptFetcher;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import eis.EILoader;
import eis.EnvironmentInterfaceStandard;
import eis.exceptions.ActException;
import eis.exceptions.AgentException;
import eis.exceptions.ManagementException;
import eis.exceptions.NoEnvironmentException;
import eis.exceptions.PerceiveException;
import eis.exceptions.RelationException;
import eis.iilang.Action;
import eis.iilang.EnvironmentState;
import eis.iilang.Identifier;
import eis.iilang.Numeral;
import eis.iilang.Percept;


public class EiTests {
	
	public static final String jarName = "ita.jar";
	
	private static EnvironmentInterfaceStandard ei;
	private static LinkedList<String> testAgents = new LinkedList<String>(); 
	private static String TEST_AGENT;
	private static PerceptFetcher fetcher;

	@BeforeClass public static void setUpBeforeClass() throws IOException, ManagementException, RelationException, AgentException {
		ei = EILoader.fromJarFile(new File(jarName));
		fetcher = new PerceptFetcher(ei);
		for (String entity : ei.getEntities()) {
			String agentName = "agentFor" + entity; 
			testAgents.add(agentName);
			ei.registerAgent(agentName);
			ei.associateEntity(agentName, entity);
		}
		TEST_AGENT = testAgents.getFirst();
		fetcher.setTestAgent(TEST_AGENT);
		// TODO: how to start the environment?
		ei.start();
	}
	
	@AfterClass	public static void tearDownAfterClass() throws Exception {
		ei.kill();
	}
	
	@Before public void setUp() throws AgentException, RelationException, ManagementException {

	}
	
	@After public void tearDown() throws RelationException, AgentException {
//		for (int i = 0; i < ei.getEntities().size(); i++) {
//			//ei.freePair(testAgents.get(i), ei.getEntities().get(i));
//			ei.unregisterAgent(testAgents.get(i));
//		}
	}
	
	@Test public void environmentRunningTest() {
		assertTrue(ei.getState() == EnvironmentState.RUNNING);
	}

	@Test public void entityListTest() {
		Collection<String> entities = ei.getEntities(); 
		assertTrue(entities.size() >= 1);
		assertTrue(entities.size() <= 8);
		for (String entity : entities) {
			assertNotNull(entity);
			assertTrue(entity.length() > 0);
		}
	}
	
	@Test public void lightTest() throws PerceiveException, NoEnvironmentException, ActException {
		assertEquals(VacBotEntity.STATE_OFF, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_LIGHT));
		ei.performAction(TEST_AGENT, new Action("light", new Identifier(VacBotEntity.STATE_ON)));
		assertEquals(VacBotEntity.STATE_ON, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_LIGHT));
		ei.performAction(TEST_AGENT, new Action("light", new Identifier(VacBotEntity.STATE_OFF)));
		assertEquals(VacBotEntity.STATE_OFF, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_LIGHT));
	}
	
	@Test (expected=ActException.class) public void lightFailTest() throws ActException, NoEnvironmentException {
		try {
			ei.performAction(TEST_AGENT, new Action("light", new Identifier("Wrong state!")));
		} catch (ActException ae) {
			assertEquals(ActException.FAILURE, ae.getType());
			throw ae;
		}
	}
	
	@Test public void squarePerceptsTest() throws PerceiveException, NoEnvironmentException {
		LinkedList<Percept> squarePercepts = fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(6, squarePercepts.size());
		assertEquals(RelativeDirection.LEFT, fetcher.getFirstParameterFrom(squarePercepts.get(0)));
		assertEquals(RelativeDirection.FORWARD_LEFT, fetcher.getFirstParameterFrom(squarePercepts.get(1)));
		assertEquals(RelativeDirection.FORWARD, fetcher.getFirstParameterFrom(squarePercepts.get(2)));
		assertEquals(RelativeDirection.FORWARD_RIGHT, fetcher.getFirstParameterFrom(squarePercepts.get(3)));
		assertEquals(RelativeDirection.RIGHT, fetcher.getFirstParameterFrom(squarePercepts.get(4)));
		assertEquals(RelativeDirection.HERE, fetcher.getFirstParameterFrom(squarePercepts.get(5)));
		for (int i = 0; i < 6; i++) {
			assertTrue(fetcher.getSecondParameterFrom(squarePercepts.get(i)).matches(
					VacBotEntity.ITEM_EMPTY + "|" + VacBotEntity.ITEM_DUST + "|" 
					+ VacBotEntity.ITEM_VAC + "|" + VacBotEntity.ITEM_OBSTACLE));
		}
	}
	
	@Test public void taskAndDirectionPerceptsTurnTest() throws PerceiveException, NoEnvironmentException, InterruptedException, ActException {
		// Testing as much functionality as possible here to keep test running times down
		// Initially, task is none; current location, direction, and square percepts are known
		assertEquals(VacBotEntity.TASK_NONE, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept initialLocationPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(2, initialLocationPercept.getParameters().size());
		Percept initialDirectionPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertEquals(1, initialDirectionPercept.getParameters().size());
		LinkedList<Percept> initialSquarePercepts = fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(6, initialSquarePercepts.size());
		// Configure the fetcher to get a copy of the VacBot's percepts halfway through a quarter turn
		fetcher.setSleepTime(250); // 1/8th of the time to turn full-circle 
		Thread backgroundPerceptFetcher = new Thread(fetcher);
		backgroundPerceptFetcher.start();
		// Do a quarter turn by moving 0 steps to the right - this is always possible
		ei.performAction(TEST_AGENT, new Action("move", new Identifier(RelativeDirection.RIGHT),
				new Numeral(0)));
		backgroundPerceptFetcher.join();
		// Check that @ half way point, task was turn, location the same, direction and square percepts missing
		assertEquals(VacBotEntity.TASK_TURN, fetcher.getStoredSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept midTurnLocationPercept = fetcher.getStoredPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(fetcher.getFirstParameterFrom(initialLocationPercept), fetcher.getFirstParameterFrom(midTurnLocationPercept));
		assertEquals(fetcher.getSecondParameterFrom(initialLocationPercept), fetcher.getSecondParameterFrom(midTurnLocationPercept));
		Percept midTurnDirectionPercept = fetcher.getStoredPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertNull(midTurnDirectionPercept);
		LinkedList<Percept> midTurnSquarePercepts = fetcher.getStoredPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(0, midTurnSquarePercepts.size());
		// Finally, task is none, location the same, and direction has been incremented by one quarter turn
		assertEquals(VacBotEntity.TASK_NONE, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept finalLocationPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(fetcher.getFirstParameterFrom(initialLocationPercept), fetcher.getFirstParameterFrom(finalLocationPercept));
		assertEquals(fetcher.getSecondParameterFrom(initialLocationPercept), fetcher.getSecondParameterFrom(finalLocationPercept));
		String initialDirection = initialDirectionPercept.getParameters().getFirst().toProlog();
		String finalDirection = fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_DIRECTION);
		if (initialDirection.equals(Direction.NORTH)) {
			assertEquals(Direction.EAST, finalDirection);
		} else if (initialDirection.equals(Direction.EAST)) {
			assertEquals(Direction.SOUTH, finalDirection);
		} else if (initialDirection.equals(Direction.SOUTH)) {
			assertEquals(Direction.WEST, finalDirection);
		} else if (initialDirection.equals(Direction.WEST)) {
			assertEquals(Direction.NORTH, finalDirection);
		} else {
			fail("Unrecognised initial direction: " + initialDirection);
		}
		// Perceived squares are rotated by one quarter turn
		LinkedList<Percept> finalSquarePercepts = fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(6, finalSquarePercepts.size());
		for (int i = 0; i < 2; i++) {
			assertEquals(fetcher.getSecondParameterFrom(initialSquarePercepts.get(i + 2)),
					fetcher.getSecondParameterFrom(finalSquarePercepts.get(i)));
		}
		assertEquals(fetcher.getSecondParameterFrom(initialSquarePercepts.get(5)),
				fetcher.getSecondParameterFrom(finalSquarePercepts.get(5)));
	}
	
	private String findVacBotWith(String squareContents, int direction) throws PerceiveException, NoEnvironmentException {
		for (String testAgent : testAgents) {
			fetcher.setTestAgent(testAgent);
			String targetSquareContents =
				fetcher.getSecondParameterFrom(fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE).get(direction));
			if (targetSquareContents.equals(squareContents)) {
				return testAgent;
			}
		}
		return null;
	}
	
	private String findVacBotOccupying(String squareContents) throws PerceiveException, NoEnvironmentException {
		return findVacBotWith(squareContents, 5);
	}
	
	private String findVacBotFacing(String squareContents) throws PerceiveException, NoEnvironmentException {
		return findVacBotWith(squareContents, 2);
	}
	
	private String findVacBotLeftFacing(String squareContents) throws PerceiveException, NoEnvironmentException {
		return findVacBotWith(squareContents, 0);
	}
	
	private String findVacBotRightFacing(String squareContents) throws PerceiveException, NoEnvironmentException {
		return findVacBotWith(squareContents, 4);
	}
	
	@Test public void taskAndLocationPerceptsMoveTest() throws PerceiveException, NoEnvironmentException, ActException, InterruptedException {
		TEST_AGENT = findVacBotFacing(VacBotEntity.ITEM_DUST);
		if (TEST_AGENT == null) TEST_AGENT = findVacBotFacing(VacBotEntity.ITEM_EMPTY);
		// Seems like these two finds almost always succeed, without needing to turn any VacBots
		assertNotNull(TEST_AGENT);
		fetcher.setTestAgent(TEST_AGENT);
		// Initially, task is none; current location, direction and square percepts are known
		assertEquals(VacBotEntity.TASK_NONE, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept initialLocationPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(2, initialLocationPercept.getParameters().size());
		Percept initialDirectionPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertEquals(1, initialDirectionPercept.getParameters().size());
		LinkedList<Percept> initialSquarePercepts = fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(6, initialSquarePercepts.size());
		// Configure the fetcher to get a copy of the VacBot's percepts halfway through a one-square move
		fetcher.setSleepTime(750); // half of the time to move one square
		Thread backgroundPerceptFetcher = new Thread(fetcher);
		backgroundPerceptFetcher.start();
		// Move 1 step forwards
		ei.performAction(TEST_AGENT, new Action("move", new Identifier(RelativeDirection.FORWARD),
				new Numeral(1)));
		backgroundPerceptFetcher.join();
		// Check that @ half way point, task was move, direction is the same, location and square percepts missing
		assertEquals(VacBotEntity.TASK_MOVE, fetcher.getStoredSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept midMoveLocationPercept = fetcher.getStoredPercept(VacBotEntity.PERCEPT_LOCATION);
		assertNull(midMoveLocationPercept);
		Percept midMoveDirectionPercept = fetcher.getStoredPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertEquals(fetcher.getFirstParameterFrom(initialDirectionPercept), fetcher.getFirstParameterFrom(midMoveDirectionPercept));
		LinkedList<Percept> midMoveSquarePercepts = fetcher.getStoredPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(0, midMoveSquarePercepts.size());
		// Finally, task is none, location has changed by one square, direction is the same
		assertEquals(VacBotEntity.TASK_NONE, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept finalLocationPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(2, finalLocationPercept.getParameters().size());
		Percept finalDirectionPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertEquals(fetcher.getFirstParameterFrom(initialDirectionPercept), fetcher.getFirstParameterFrom(finalDirectionPercept));
		String direction = fetcher.getFirstParameterFrom(finalDirectionPercept);
		if (direction.equals(Direction.NORTH)) {
			assertEquals(fetcher.getFirstParameterFrom(initialLocationPercept),
					fetcher.getFirstParameterFrom(finalLocationPercept));
			assertEquals(Double.parseDouble(fetcher.getSecondParameterFrom(initialLocationPercept)) - 1,
					Double.parseDouble(fetcher.getSecondParameterFrom(finalLocationPercept)), 0);
		} else if (direction.equals(Direction.EAST)) {
			assertEquals(Double.parseDouble(fetcher.getFirstParameterFrom(initialLocationPercept)) + 1,
					Double.parseDouble(fetcher.getFirstParameterFrom(finalLocationPercept)), 0);
			assertEquals(fetcher.getSecondParameterFrom(initialLocationPercept),
					fetcher.getSecondParameterFrom(finalLocationPercept));
		} else if (direction.equals(Direction.SOUTH)) {
			assertEquals(fetcher.getFirstParameterFrom(initialLocationPercept),
					fetcher.getFirstParameterFrom(finalLocationPercept));
			assertEquals(Double.parseDouble(fetcher.getSecondParameterFrom(initialLocationPercept)) + 1,
					Double.parseDouble(fetcher.getSecondParameterFrom(finalLocationPercept)), 0);
		} else if (direction.equals(Direction.WEST)) {
			assertEquals(Double.parseDouble(fetcher.getFirstParameterFrom(initialLocationPercept)) - 1,
					Double.parseDouble(fetcher.getFirstParameterFrom(finalLocationPercept)), 0);
			assertEquals(fetcher.getSecondParameterFrom(initialLocationPercept),
					fetcher.getSecondParameterFrom(finalLocationPercept));
		} else {
			fail("Unrecognised direction: " + direction);
		}
		// Check initial forward-left, forward, and forward-right squares are now at left, here, and right
		LinkedList<Percept> finalSquarePercepts = fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(6, finalSquarePercepts.size());
		assertEquals(fetcher.getSecondParameterFrom(initialSquarePercepts.get(1)), fetcher.getSecondParameterFrom(finalSquarePercepts.get(0)));
		assertEquals(fetcher.getSecondParameterFrom(initialSquarePercepts.get(2)), fetcher.getSecondParameterFrom(finalSquarePercepts.get(5)));
		assertEquals(fetcher.getSecondParameterFrom(initialSquarePercepts.get(3)), fetcher.getSecondParameterFrom(finalSquarePercepts.get(4)));
	}
	
	@Test public void taskAndSquarePerceptsCleanTest() throws PerceiveException, NoEnvironmentException, ActException, InterruptedException {
		// First, find some dust to clean!
		TEST_AGENT = findVacBotOccupying(VacBotEntity.ITEM_DUST);
		if (TEST_AGENT == null) {
			TEST_AGENT = findVacBotFacing(VacBotEntity.ITEM_DUST);
			if (TEST_AGENT != null)
				ei.performAction(TEST_AGENT, new Action("move", new Identifier(RelativeDirection.FORWARD), new Numeral(1)));
		}
		if (TEST_AGENT == null) {
			TEST_AGENT = findVacBotLeftFacing(VacBotEntity.ITEM_DUST);
			if (TEST_AGENT != null)
				ei.performAction(TEST_AGENT, new Action("move", new Identifier(RelativeDirection.LEFT), new Numeral(1)));
		}
		if (TEST_AGENT == null) {
			TEST_AGENT = findVacBotRightFacing(VacBotEntity.ITEM_DUST);
			if (TEST_AGENT != null)
				ei.performAction(TEST_AGENT, new Action("move", new Identifier(RelativeDirection.RIGHT), new Numeral(1)));
		}
		assertNotNull(TEST_AGENT);
		fetcher.setTestAgent(TEST_AGENT);
		// Initially, task is none, location and direction known, and current square is dusty
		assertEquals(VacBotEntity.TASK_NONE, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept initialLocationPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(2, initialLocationPercept.getParameters().size());
		Percept initialDirectionPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertEquals(1, initialDirectionPercept.getParameters().size());
		assertEquals(VacBotEntity.ITEM_DUST, fetcher.getSecondParameterFrom(fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE).get(5)));
		// Configure the fetcher to get a copy of the VacBot's percepts halfway through a clean
		fetcher.setSleepTime(1500); // half of the time to clean a dusty square
		Thread backgroundPerceptFetcher = new Thread(fetcher);
		backgroundPerceptFetcher.start();
		// Clean
		ei.performAction(TEST_AGENT, new Action("clean"));
		backgroundPerceptFetcher.join();
		// Check that @ half way point, task was clean, location the same, direction and square percepts missing
		assertEquals(VacBotEntity.TASK_CLEAN, fetcher.getStoredSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept midCleanLocationPercept = fetcher.getStoredPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(fetcher.getFirstParameterFrom(initialLocationPercept), fetcher.getFirstParameterFrom(midCleanLocationPercept));
		assertEquals(fetcher.getSecondParameterFrom(initialLocationPercept), fetcher.getSecondParameterFrom(midCleanLocationPercept));
		LinkedList<Percept> midCleanSquarePercepts = fetcher.getStoredPercepts(VacBotEntity.PERCEPT_SQUARE);
		assertEquals(0, midCleanSquarePercepts.size());
		Percept midCleanDirectionPercept = fetcher.getStoredPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertNull(midCleanDirectionPercept);
		// Finally, task is none, location and direction the same, and current square is empty
		assertEquals(VacBotEntity.TASK_NONE, fetcher.getFreshSingleParamPercept(VacBotEntity.PERCEPT_TASK));
		Percept finalLocationPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_LOCATION);
		assertEquals(fetcher.getFirstParameterFrom(initialLocationPercept), fetcher.getFirstParameterFrom(finalLocationPercept));
		assertEquals(fetcher.getSecondParameterFrom(initialLocationPercept), fetcher.getSecondParameterFrom(finalLocationPercept));
		Percept finalDirectionPercept = fetcher.getFreshPercept(VacBotEntity.PERCEPT_DIRECTION);
		assertEquals(fetcher.getFirstParameterFrom(initialDirectionPercept), fetcher.getFirstParameterFrom(finalDirectionPercept));
		assertEquals(VacBotEntity.ITEM_EMPTY, fetcher.getSecondParameterFrom(fetcher.getFreshPercepts(VacBotEntity.PERCEPT_SQUARE).get(5)));
	}
	
}
