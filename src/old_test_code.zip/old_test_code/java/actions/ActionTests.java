package test.java.actions;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import main.java.actions.Action;
import main.java.actions.ImpossibleActionException;
import main.java.actions.UnavailableActionException;
import main.java.grid.ModelObject;

import org.junit.Test;


public class ActionTests {
	
	@Test public void oneStepActionTest() throws InterruptedException, ImpossibleActionException, UnavailableActionException  {
		Recorder recorder = new Recorder();
		Action action = new DummyAction(10, 1, recorder);
		action.execute();
		assertEquals(2, recorder.events.size());
		assertTrue(recorder.timeSpan() > 5);
		assertTrue(recorder.timeSpan() < 15);
	}
	
	@Test public void twoStepActionTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		Recorder recorder = new Recorder();
		Action action = new DummyAction(20, 2, recorder);
		action.execute();
		assertEquals(3, recorder.events.size());
		assertTrue(recorder.eventTime(1) > 5);
		assertTrue(recorder.eventTime(1) < 15);
		assertTrue(recorder.timeSpan() > 15);
		assertTrue(recorder.timeSpan() < 25);
	}
	
	@Test public void threeStepActionTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		Recorder recorder = new Recorder();
		Action action = new DummyAction(30, 3, recorder);
		action.execute();
		assertEquals(4, recorder.events.size());
		assertTrue(recorder.eventTime(1) > 5);
		assertTrue(recorder.eventTime(1) < 15);
		assertTrue(recorder.eventTime(2) > 15);
		assertTrue(recorder.eventTime(2) < 25);
		assertTrue(recorder.timeSpan() > 25);
		assertTrue(recorder.timeSpan() < 35);
	}

	@Test (expected=ImpossibleActionException.class)
	public void exceptionInInitialiserTest() throws InterruptedException, ImpossibleActionException, UnavailableActionException {
		Recorder recorder = new Recorder();
		Action action = new BadInitialiserAction(20, 4, recorder);
		assertNull(recorder.getAction());
		try {
			action.execute();
		} finally {
			assertEquals(0, recorder.events.size());
			assertNull(recorder.getAction());
		}
	}
	
	@Test (expected=UnavailableActionException.class)
	public void concurrentActionsTest() throws InterruptedException, ImpossibleActionException, UnavailableActionException {
		Recorder recorder = new Recorder();
		final Action action1 = new DummyAction(50, 1, recorder);
		assertNull(recorder.getAction());
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					action1.execute();
				} catch (Exception e) {
					// Should never happen
					e.printStackTrace();
				}
			}
		});
		// Kick off the first, successful action in thread t
		t.start();
		Thread.sleep(10);
		// Now in this thread, the recorder ModelObject already has action1
		assertEquals(action1, recorder.getAction());
		Action action2 = new DummyAction(50, 1, recorder);
		try {
			// Attempting to start action2 while action1 still running throws UnavailableException
			action2.execute();
		} finally {
			t.join();
			assertEquals(2, recorder.events.size());
			assertTrue(recorder.timeSpan() > 48);
			assertTrue(recorder.timeSpan() < 52);
			assertNull(recorder.getAction());
		}
	}
	
	private static class Recorder extends ModelObject {
		
		public List<Long> events = new ArrayList<Long>(100);
		
		public void fireEvent(String eventName, ModelObject source) {
			events.add(System.currentTimeMillis());
		}
		
		public long timeSpan() {
			return events.get(events.size() - 1) - events.get(0);
		}
		
		public long eventTime(int index) {
			return events.get(index) - events.get(0);
		}
	}
	
	private static class DummyAction extends Action {

		private long duration;
		private int steps;
		
		protected DummyAction(long duration, int steps, Recorder eventRecorder) {
			super(eventRecorder);
			this.duration = duration;
			this.steps = steps;
		}

		protected long duration() {
			return duration;
		}

		protected void executeOneStep() {}
		protected void finalise() {}
		protected void initialise() throws ImpossibleActionException, UnavailableActionException {}

		protected int numberOfSteps() {
			return steps;
		}
		
	}
	
	private static class BadInitialiserAction extends DummyAction {

		protected BadInitialiserAction(long duration, int steps, Recorder eventRecorder) {
			super(duration, steps, eventRecorder);
		}
		
		protected void initialise() throws ImpossibleActionException, UnavailableActionException {
			throw new ImpossibleActionException("Can't initialise this action!");
		}
	}
}
