package test.java.actions;

import static org.junit.Assert.*;
import main.java.grid.Direction;
import main.java.grid.Grid;
import main.java.grid.GridObject;
import main.java.grid.GridPoint;
import main.java.grid.ModelListener;
import main.java.grid.MovingObject;
import main.java.grid.Square;

import org.junit.Test;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.jmock.integration.junit4.JUnit4Mockery;

public class TurnTests {

	Mockery context = new JUnit4Mockery();
	final ModelListener listener = context.mock(ModelListener.class);
	final Sequence turnSteps = context.sequence("turn steps");

	@Test public void quarterTurnTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final TurningThing thing = new TurningThing(Direction.north);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.start")), with(equal(thing))); inSequence(turnSteps);
			exactly(15).of (listener).eventFired(
					with(equal("actions.Turn.step")), with(equal(thing))); inSequence(turnSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.stop")), with(equal(thing))); inSequence(turnSteps);
		}});
		Turn turn = new Turn(thing, Direction.east);
		turn.execute();
		assertEquals(Direction.east, thing.getDirection());
	}
	
	@Test public void halfTurnTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final TurningThing thing = new TurningThing(Direction.north);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.start")), with(equal(thing))); inSequence(turnSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Turn.step")), with(equal(thing))); inSequence(turnSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.stop")), with(equal(thing))); inSequence(turnSteps);
		}});
		Turn turn = new Turn(thing, Direction.south);
		turn.execute();
		assertEquals(Direction.south, thing.getDirection());
	}
	
	@Test public void reverseTurnTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final TurningThing thing = new TurningThing(Direction.north);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.start")), with(equal(thing))); inSequence(turnSteps);
			exactly(15).of (listener).eventFired(
					with(equal("actions.Turn.step")), with(equal(thing))); inSequence(turnSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.stop")), with(equal(thing))); inSequence(turnSteps);
		}});
		Turn turn = new Turn(thing, Direction.west);
		turn.execute();
		assertEquals(Direction.west, thing.getDirection());
	}
	
	public static class TurningThing extends MovingObject {

		public TurningThing(Direction direction) {
			super(new Grid(1, 1), new GridPoint(0,0), direction);
		}

		public long getTimeToMove() {
			return 0;
		}
		
		public long getTimeToTurn() {
			return 40;
		}

		public GridObject getObstruction(Square square) {
			return null;
		}
		
	}
}
