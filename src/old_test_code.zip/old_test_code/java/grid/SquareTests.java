package test.java.grid;

import static org.junit.Assert.*;

import org.junit.Test;

public class SquareTests {

	private Grid grid = new Grid(4,4);
	private GridPoint point = new GridPoint(1,2);
	
	// Set of tests for the GridObject layering mechanism
	@Test public void getGridObjectTest() {
		Thing thing = new Thing(grid);
		Wotsit wotsit = new Wotsit(grid);
		Square square = new Square(point);
		square.add(thing);
		square.add(wotsit);
		assertEquals(thing, square.get(Thing.class));
		assertEquals(wotsit, square.get(Wotsit.class));
		assertNull(square.get(GridObject.class));
	}
	
	@Test public void hasGridObjectTest() {
		Thing thing = new Thing(grid);
		Square square = new Square(point);
		square.add(thing);
		assertTrue(square.has(Thing.class));
		assertTrue(!square.has(Wotsit.class));
	}
	
	@Test public void getInstaceOfTest() {
		Thing thing = new Thing(grid);
		Wotsit wotsit = new Wotsit(grid);
		Square square = new Square(point);
		square.add(thing);
		square.add(wotsit);
		assertEquals(thing, square.getInstanceOf(Thing.class));
		assertEquals(wotsit, square.getInstanceOf(GridObject.class));
		assertEquals(wotsit, square.getInstanceOf(ModelObject.class));
		assertNull(square.getInstanceOf(Grid.class));
	}
	
	@Test public void hasInstanceOfTest() {
		Thing thing = new Thing(grid);
		Wotsit wotsit = new Wotsit(grid);
		Square square = new Square(point);
		square.add(thing);
		square.add(wotsit);
		assertTrue(square.hasInstanceOf(Thing.class));
		assertTrue(square.hasInstanceOf(Wotsit.class));
		assertTrue(square.hasInstanceOf(GridObject.class));
		assertTrue(square.hasInstanceOf(ModelObject.class));
		assertFalse(square.hasInstanceOf(Grid.class));
	}
	
	@Test public void removeTopGridObjectTest() {
		Thing thing1 = new Thing(grid);
		Thing thing2 = new Thing(grid);
		Square square = new Square(point);
		square.add(thing1);
		square.add(thing2);
		assertEquals(thing2, square.get(Thing.class));
		square.remove(thing2);
		assertEquals(thing1, square.get(Thing.class));
	}
	
	@Test public void removeBottomGridObjectTest() {
		Thing thing1 = new Thing(grid);
		Thing thing2 = new Thing(grid);
		Square square = new Square(point);
		square.add(thing1);
		square.add(thing2);
		assertEquals(thing2, square.get(Thing.class));
		square.remove(thing1);
		assertEquals(thing2, square.get(Thing.class));
	}
	
	// Two silly example GridObjects
	private class Thing extends GridObject {
		public Thing(Grid grid) {
			super(grid, new GridPoint(0,0));
		}
	}
	private class Wotsit extends GridObject {
		public Wotsit(Grid grid) {
			super(grid, new GridPoint(0,0));
		}
	}
}
