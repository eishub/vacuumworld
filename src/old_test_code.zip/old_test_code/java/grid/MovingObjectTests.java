package test.java.grid;

import static org.junit.Assert.assertEquals;
import main.java.actions.ImpossibleActionException;
import main.java.actions.UnavailableActionException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Test;

public class MovingObjectTests {
	
	// 3 x 3 grid with moving thing in south middle square
	private final Grid testGrid = new Grid(3, 3);
	Mockery context = new JUnit4Mockery();
	final ModelListener listener = context.mock(ModelListener.class);
	final Sequence moveSteps = context.sequence("turn steps");

	@Test public void twoSquareMoveTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final MovingThing thing = new MovingThing(Direction.north);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Move.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.stop")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Move.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.stop")), with(equal(thing))); inSequence(moveSteps);
		}});
		thing.move(2, Direction.north);
		assertEquals(1.0, thing.getX(), 0.001);
		assertEquals(0.0, thing.getY(), 0.001);
	}
	
	@Test (expected=ImpossibleActionException.class)
	public void impossibleThreeSquareMoveTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final MovingThing thing = new MovingThing(Direction.north);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Move.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.stop")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Move.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.stop")), with(equal(thing))); inSequence(moveSteps);
		}});
		try {
			thing.move(3, Direction.north);
		} finally {
			assertEquals(1.0, thing.getX(), 0.001);
			assertEquals(0.0, thing.getY(), 0.001);
		}
	}
	
	@Test public void turnAndMoveTest() throws InterruptedException,
	ImpossibleActionException, UnavailableActionException {
		final MovingThing thing = new MovingThing(Direction.west);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(15).of (listener).eventFired(
					with(equal("actions.Turn.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Turn.stop")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Move.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.stop")), with(equal(thing))); inSequence(moveSteps);
		}});
		thing.move(1, Direction.north);
		assertEquals(1.0, thing.getX(), 0.001);
		assertEquals(1.0, thing.getY(), 0.001);
	}
	
	public class MovingThing extends MovingObject {

		public MovingThing(Direction direction) {
			super(testGrid, new GridPoint(1, 2), direction);
		}

		public long getTimeToMove() {
			return 40;
		}

		public long getTimeToTurn() {
			return 0;
		}

		public GridObject getObstruction(Square square) {
			return null;
		}
		
	}
}
