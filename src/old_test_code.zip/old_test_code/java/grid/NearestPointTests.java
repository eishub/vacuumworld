package test.java.grid;

import static org.junit.Assert.*;

import org.junit.Test;


public class NearestPointTests {
	
	// MovingThing is always located in the centre of a 3x3 grid
	
	@Test public void nearestPointsFromNorthTest() {
		MovingThing thing = new MovingThing(Direction.north);
		assertTrue(new GridPoint(1,1).equalsGridPoint(thing.getNearestPoint(RelativeDirection.here)));
		assertTrue(new GridPoint(1,0).equalsGridPoint(thing.getNearestPoint(RelativeDirection.forward)));
		assertTrue(new GridPoint(0,1).equalsGridPoint(thing.getNearestPoint(RelativeDirection.left)));
		assertTrue(new GridPoint(2,1).equalsGridPoint(thing.getNearestPoint(RelativeDirection.right)));
		assertTrue(new GridPoint(0,0).equalsGridPoint(thing.getNearestPoint(RelativeDirection.forwardLeft)));
		assertTrue(new GridPoint(2,0).equalsGridPoint(thing.getNearestPoint(RelativeDirection.forwardRight)));
		assertTrue(new GridPoint(1,2).equalsGridPoint(thing.getNearestPoint(RelativeDirection.back)));
	}

	@Test public void nearestPointsFromEastTest() {
		MovingThing thing = new MovingThing(Direction.east);
		assertTrue(new GridPoint(1,1).equalsGridPoint(thing.getNearestPoint(RelativeDirection.here)));
		assertTrue(new GridPoint(2,1).equalsGridPoint(thing.getNearestPoint(RelativeDirection.forward)));
		assertTrue(new GridPoint(1,0).equalsGridPoint(thing.getNearestPoint(RelativeDirection.left)));
		assertTrue(new GridPoint(1,2).equalsGridPoint(thing.getNearestPoint(RelativeDirection.right)));
		assertTrue(new GridPoint(2,0).equalsGridPoint(thing.getNearestPoint(RelativeDirection.forwardLeft)));
		assertTrue(new GridPoint(2,2).equalsGridPoint(thing.getNearestPoint(RelativeDirection.forwardRight)));
		assertTrue(new GridPoint(0,1).equalsGridPoint(thing.getNearestPoint(RelativeDirection.back)));
	}
	
	private static class MovingThing extends MovingObject {

		public MovingThing(Direction direction) {
			super(new Grid(3,3), new GridPoint(1,1), direction);
		}

		public long getTimeToMove() {
			return 0;
		}

		public long getTimeToTurn() {
			return 0;
		}

		public GridObject getObstruction(Square square) {
			return null;
		}
		
	}
}
